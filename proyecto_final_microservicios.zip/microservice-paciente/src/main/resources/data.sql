
INSERT INTO paciente (nombre, apellido, rut, fecha_nacimiento, correo, telefono, direccion)
VALUES
('Juan', 'Pérez', '12345678-9', '1990-05-15', 'juan.perez@example.com', '+56912345678', 'Calle Falsa 123'),
('María', 'Gómez', '98765432-1', '1985-11-23', 'maria.gomez@example.com', '+56987654321', 'Av. Siempre Viva 742');
